# Aleksi Workbench 整体优化报告

Date: 2026-08-30

Baseline: `0.1.5-rc.1 Final Freeze`

Scope: 在不改变 Markdown 权威数据、Vault 事务语义、桌面认证协议和既有产品决策的前提下，优化启动性能、状态一致性与工程门禁。

## 结果摘要

| 指标 | 优化前 | 优化后 | 变化 |
| --- | ---: | ---: | ---: |
| Today 直达所需 JS（minified） | 555.67 kB | 385.10 kB | -30.7% |
| Today 直达所需 JS（gzip） | 171.70 kB | 124.05 kB | -27.7% |
| 首屏共享 CSS（minified） | 59.13 kB | 34.81 kB | -41.1% |
| 首屏共享 CSS（gzip） | 10.98 kB | 7.15 kB | -34.9% |
| ESLint warnings | 13 | 0 | 零 warning gate |

JS 的“优化后”口径为 Today 直达所需的 app shell、React core 与 TanStack Query 三个稳定块之和；Reader、Cards、Graph、Review、Diagnosis、Verification、Settings、Markdown/KaTeX 与入口动效均不计入未使用页面的首屏负载。

## 已实施优化

### 1. 启动与导航

- Today 保持同步首屏，避免根路由出现不必要的加载闪烁。
- Reader、Cards、Graph、Review、Diagnosis、Verification 按路由独立加载。
- Settings 首次打开时加载，关闭后保留实例，避免重复初始化和请求抖动。
- 导航项在鼠标悬停或键盘聚焦时预取对应路由。
- Reader、Cards 与 Graph 的 CSS 跟随功能块加载，不再全部进入共享首屏 CSS。
- React、TanStack Query、Markdown/KaTeX 与入口动效采用稳定 chunk 边界，改善缓存复用并消除单一 500 kB 主包。
- 异步路由提供可访问的 `role="status"` 加载反馈。

### 2. 状态一致性

- 卡片 URL 恢复与详情加载改用稳定 callback，避免 effect 捕获旧的 dirty state 或 URL state。
- 诊断草稿、复习草稿和验证草稿使用稳定快照对象，避免无关重渲染重复写入本地存储。
- 复习恢复显式纳入队列与路由 state 依赖，保证目标卡片切换时使用当前数据。
- 飞轮选中概念以完整对象变化为同步边界，服务端同名概念更新后能重新推导阶段。
- 长文档虚拟窗口高度在测量版本变化时明确重算，保留性能缓存并消除隐式依赖。
- 验证 verdict reset 收束为单一稳定操作，减少跨页面 setter 组合产生的遗漏风险。

### 3. 工程与兼容性

- ESLint 从允许 13 个 warning 收紧为 `--max-warnings=0`。
- 开发引擎契约从无上界的 `>=22` 收紧为 `>=22 <23`，与 README、CI 和桌面 bundled runtime 的 Node 22.23.1 基线一致。
- 子进程隔离测试改用 Node `--import tsx` loader，避免依赖 tsx CLI IPC pipe，在受限执行环境中仍可验证生产环境隔离。
- 新增 Vite chunk 边界回归断言，并要求每条注册路由提供预取入口。

## 验证证据

- TypeScript typecheck: PASS
- ESLint zero-warning gate: PASS
- Vitest: 98 files PASS；767 tests PASS；1 Windows-only path-alias test SKIPPED
- Vite production build: PASS
- Font delivery verification: PASS
- Current contract synchronization: PASS
- Source security scan: 457 files scanned；0 findings
- npm audit: 0 info / low / moderate / high / critical

## 未在本环境声称完成

- 未生成或签名 Windows NSIS 安装器。
- 未替代 GitHub Actions 的 Windows qualification、真实安装/升级/卸载和 WebView2 矩阵。
- 未改变当前 `unsigned-preview` 发布身份。

这些仍应按现有 `windows-qualification.yml` 与稳定发布证据链执行。
